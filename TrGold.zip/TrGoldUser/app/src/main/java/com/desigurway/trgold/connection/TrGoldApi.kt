package com.desigurway.trgold.connection

import com.desigurway.trgold.model.StatusMessageModel
import com.desigurway.trgold.model.login.LoginModel
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

/**
 * Created by SR00136 on 20 Apr, 2021
 */
interface TrGoldApi {

    @FormUrlEncoded
    @POST("register")
    suspend fun userRegistration(
        @Field("user_name") name: String,
        @Field("user_email") email: String,
        @Field("user_phone") phone: String,
        @Field("address") address: String,
        @Field("password") password: String,
        @Field("user_type") userType:String

    ): Response<StatusMessageModel>


    @FormUrlEncoded
    @POST("login")
    suspend fun userLogin(
        @Field("user_email") email:String,
        @Field("password") password:String
    ):Response<LoginModel>


    @FormUrlEncoded
    @POST("generateOtp")
    suspend fun  generateOtp(
        @Field("user_email") email:String
    ):Response<StatusMessageModel>


    @FormUrlEncoded
    @POST("verifyOtp")
    suspend fun verifyOtp(
        @Field("user_email") email: String,
        @Field("otp") otp:String
    ):Response<StatusMessageModel>


    @FormUrlEncoded
    @POST("changePassword")
    suspend fun changePassword(
        @Field("user_email") email: String,
        @Field("password") password: String
    ):Response<StatusMessageModel>
}