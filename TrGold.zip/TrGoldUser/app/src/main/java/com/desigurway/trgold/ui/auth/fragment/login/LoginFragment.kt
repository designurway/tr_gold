package com.desigurway.trgold.ui.auth.fragment.login

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import com.desigurway.trgold.R
import com.desigurway.trgold.connection.BaseClient
import com.desigurway.trgold.databinding.FragmentLoginBinding
import com.desigurway.trgold.model.login.LoginModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.lang.Exception


class LoginFragment : Fragment() {

    lateinit var binding: FragmentLoginBinding
    lateinit var mContext: Context
    lateinit var emailEt: EditText
    lateinit var passwordEt: EditText
    lateinit var forgotPwdTv:TextView
    lateinit var submitLoginBtn: Button
    lateinit var actions:NavDirections

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        mContext = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        emailEt = binding.eamilEt
        passwordEt = binding.passwordEt
        forgotPwdTv=binding.forgotPaswordTv
        submitLoginBtn = binding.loginBtn


        forgotPwdTv.setOnClickListener {
            actions=LoginFragmentDirections.actionLoginFragmentToEnterEmailForgPassFragment()
            Navigation.findNavController(view).navigate(actions)
        }

        submitLoginBtn.setOnClickListener {
            val email = emailEt.text.toString().trim()
            val pwd = passwordEt.text.toString().trim()

            if (email.isEmpty()) {
                emailEt.error = "Required fields"
                emailEt.requestFocus()
                return@setOnClickListener

            }

            if (pwd.isEmpty()) {
                passwordEt.error = "Required fields"
                passwordEt.requestFocus()
                return@setOnClickListener
            }

            loginUser(email, pwd)
        }


    }

    private fun loginUser(email: String, pwd: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response=userLogin(email,pwd)
                if(response.isSuccessful){
                    val data=response.body()
                    if(data?.status.equals("1")){
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                    }
                }else{
                    Toast.makeText(mContext, response.message(), Toast.LENGTH_SHORT).show()

                }
            }catch (e:Exception){
                Toast.makeText(mContext, e.localizedMessage, Toast.LENGTH_SHORT).show()

            }
        }


    }

    private suspend fun userLogin(
        email: String,
        password: String
    ): Response<LoginModel> {
        return withContext(Dispatchers.IO) {
            BaseClient.getInstance.userLogin(email, password)
        }
    }


}