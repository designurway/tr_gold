package com.desigurway.trgold.model

/**
 * Created by SR00136 on 20 Apr, 2021
 */
data class StatusMessageModel (
    val status:String,
    val message:String

)