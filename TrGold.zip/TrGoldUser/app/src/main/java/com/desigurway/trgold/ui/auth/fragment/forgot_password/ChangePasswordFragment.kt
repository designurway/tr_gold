package com.desigurway.trgold.ui.auth.fragment.forgot_password

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.navArgs
import com.desigurway.trgold.R
import com.desigurway.trgold.connection.BaseClient
import com.desigurway.trgold.databinding.FragmentChangePasswordBinding
import com.desigurway.trgold.model.StatusMessageModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.lang.Exception


class ChangePasswordFragment : Fragment() {
    lateinit var binding: FragmentChangePasswordBinding
    lateinit var mContext: Context
    lateinit var pwdEt: EditText
    lateinit var confPwdEt: EditText
    lateinit var submitPasswordBtn: Button
    val args: ChangePasswordFragmentArgs by navArgs()
    

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentChangePasswordBinding.inflate(inflater, container, false)
        mContext = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        pwdEt = binding.passEt
        confPwdEt = binding.cPassEt
        submitPasswordBtn = binding.resetPassbtn


        submitPasswordBtn.setOnClickListener {
            val email = args.emailId
            val newPwd = pwdEt.text.toString().trim()
            val confPwd = confPwdEt.text.toString().trim()

            if (newPwd.isEmpty()) {
                pwdEt.error = "Required fields"
                pwdEt.requestFocus()
                return@setOnClickListener
            }

            if (confPwd.isEmpty()) {
                confPwdEt.error = "Required fields"
                confPwdEt.requestFocus()
                return@setOnClickListener
            }

            if (newPwd != confPwd) {
                Toast.makeText(mContext, "Passwords do not match", Toast.LENGTH_SHORT).show()
            }


            changePassword(email, newPwd, view)
        }
    }

    private fun changePassword(email: String, newPwd: String, view: View) {

        CoroutineScope(Dispatchers.Main).launch {
            try {

                val response = changeUserPwd(email, newPwd)
                if (response.isSuccessful) {
                    val data = response.body()
                    if (data?.status.equals("1")) {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                    }
                } else {
                    Toast.makeText(mContext, response.message(), Toast.LENGTH_SHORT).show()

                }

            } catch (e: Exception) {
                Toast.makeText(
                    mContext,
                    "Exception Occurred: ${e.localizedMessage}",
                    Toast.LENGTH_SHORT
                ).show()

            }
        }

    }

    private suspend fun changeUserPwd(
        email: String,
        password: String
    ): Response<StatusMessageModel> {
        return withContext(Dispatchers.IO) {
            BaseClient.getInstance.changePassword(email, password)
        }
    }

}