    package com.desigurway.trgold.ui.auth.fragment.forgot_password

import android.content.Context
import android.os.Binder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.desigurway.trgold.R
import com.desigurway.trgold.connection.BaseClient
import com.desigurway.trgold.databinding.FragmentVerifyOtpFogPassBinding
import com.desigurway.trgold.model.StatusMessageModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.lang.Exception


class VerifyOtpFogPassFragment : Fragment() {

    lateinit var binding: FragmentVerifyOtpFogPassBinding
    lateinit var mContext: Context
    lateinit var otpEt: EditText
    lateinit var submitOtpBtn: Button
    lateinit var resendOtpTv:TextView
    val args: VerifyOtpFogPassFragmentArgs by navArgs()
    lateinit var actions:NavDirections

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentVerifyOtpFogPassBinding.inflate(inflater, container, false)
        mContext = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        otpEt = binding.otpEt
        submitOtpBtn = binding.submitOtp
        resendOtpTv=binding.resendEmail
        val emailFromForgotPass = args.emailId
        resendOtpTv.setOnClickListener {
            verifyAndGenerateOtp(emailFromForgotPass,view)
        }

        submitOtpBtn.setOnClickListener {

            val otp = otpEt.text.toString().trim()


            if (otp.isEmpty()) {
                otpEt.error = "Required fields"
                otpEt.requestFocus()
                return@setOnClickListener
            }


            submitOtp(view, emailFromForgotPass, otp)
        }


    }




    private fun submitOtp( view: View,email: String, otp: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val res = verifyOtp(email, otp)
                if (res.isSuccessful) {
                    val data = res.body()
                    if (data?.status.equals("1")) {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                        actions =
                            VerifyOtpFogPassFragmentDirections.actionVerifyOtpFogPassFragmentToChangePasswordFragment(
                                email
                            )
                        Navigation.findNavController(view).navigate(actions)

                    } else {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                    }
                } else {
                    Toast.makeText(mContext, res.message(), Toast.LENGTH_SHORT).show()

                }
            } catch (e: Exception) {
                Toast.makeText(mContext, "exception: ${e.localizedMessage}", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    }


    private suspend fun verifyOtp(email: String, otp: String): Response<StatusMessageModel> {
        return withContext(Dispatchers.IO) {
            BaseClient.getInstance.verifyOtp(email, otp)
        }
    }
    private fun verifyAndGenerateOtp(email: String, view: View) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val res = userVerifyGenerateOtp(email)
                if (res.isSuccessful) {
                    val data = res.body()
                    if (data?.status.equals("1")) {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                        actions =
                            EnterEmailForgPassFragmentDirections.actionEnterEmailForgPassFragmentToVerifyOtpFogPassFragment(
                                email
                            )
                        Navigation.findNavController(view).navigate(actions)

                    } else {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                    }
                } else {
                    Toast.makeText(mContext, res.message(), Toast.LENGTH_SHORT).show()

                }
            } catch (e: Exception) {
                Toast.makeText(mContext, "exception: ${e.localizedMessage}", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    }

    private suspend fun userVerifyGenerateOtp(email: String): Response<StatusMessageModel> {
        return withContext(Dispatchers.IO) {
            BaseClient.getInstance.generateOtp(email)
        }
    }

}