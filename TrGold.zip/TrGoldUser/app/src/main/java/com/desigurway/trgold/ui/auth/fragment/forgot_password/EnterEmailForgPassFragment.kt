package com.desigurway.trgold.ui.auth.fragment.forgot_password

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import com.desigurway.trgold.R
import com.desigurway.trgold.connection.BaseClient
import com.desigurway.trgold.databinding.FragmentEnterEmailForgPassBinding
import com.desigurway.trgold.model.StatusMessageModel
import com.desigurway.trgold.utils.AndroidUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.lang.Exception


class EnterEmailForgPassFragment : Fragment() {

    lateinit var binding: FragmentEnterEmailForgPassBinding
    lateinit var mContext: Context
    lateinit var emailEt: EditText
    lateinit var submitEmailBtn: Button
    lateinit var actions: NavDirections

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentEnterEmailForgPassBinding.inflate(inflater, container, false)
        mContext = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        emailEt = binding.emailEt
        submitEmailBtn=binding.registerBtn

        submitEmailBtn.setOnClickListener {
            val email = emailEt.text.toString().trim()

            if (email.isEmpty()) {
                emailEt.error = "Required fields"
                emailEt.requestFocus()
                return@setOnClickListener
            }

            if (!AndroidUtils().validEmail(email)) {
                emailEt.error = "Enter valid Email"
                emailEt.requestFocus()
                return@setOnClickListener
            }
            verifyAndGenerateOtp(email, view)

        }


    }

    private fun verifyAndGenerateOtp(email: String, view: View) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val res = userVerifyGenerateOtp(email)
                if (res.isSuccessful) {
                    val data = res.body()
                    if (data?.status.equals("1")) {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                        actions =
                            EnterEmailForgPassFragmentDirections.actionEnterEmailForgPassFragmentToVerifyOtpFogPassFragment(
                                email
                            )
                        Navigation.findNavController(view).navigate(actions)

                    } else {
                        Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                    }
                } else {
                    Toast.makeText(mContext, res.message(), Toast.LENGTH_SHORT).show()

                }
            } catch (e: Exception) {
                Toast.makeText(mContext, "exception: ${e.localizedMessage}", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    }

    private suspend fun userVerifyGenerateOtp(email: String): Response<StatusMessageModel> {
        return withContext(Dispatchers.IO) {
            BaseClient.getInstance.generateOtp(email)
        }
    }


}