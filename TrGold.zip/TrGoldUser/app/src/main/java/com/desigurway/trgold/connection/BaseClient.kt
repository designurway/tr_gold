package com.desigurway.trgold.connection

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Created by SR00136 on 20 Apr, 2021
 */
object BaseClient {

private const val BASE_URL="http://192.168.4.165:8000/api/customer/"

val getInstance: TrGoldApi by lazy{
    val retrofit=Retrofit.Builder().baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    retrofit.create(TrGoldApi::class.java)

}

}