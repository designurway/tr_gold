package com.desigurway.trgold.model.login

/**
 * Created by SR00136 on 21 Apr, 2021
 */
data class LoginModel(
    val status:String,
    val message:String,
    val user_data:LoginDataModel
)
