package com.desigurway.trgold.model.login

import com.google.gson.annotations.SerializedName

/**
 * Created by SR00136 on 21 Apr, 2021
 */
data class LoginDataModel(

    val mobile:String,

    val email:String,

    @SerializedName("first_name")
    val name:String,

    val password:String,

    val address:String,

    @SerializedName("registered_type")
    val type:String
)
