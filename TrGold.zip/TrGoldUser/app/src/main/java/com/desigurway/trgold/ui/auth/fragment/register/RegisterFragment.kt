package com.desigurway.trgold.ui.auth.fragment.register

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import com.desigurway.trgold.R
import com.desigurway.trgold.connection.BaseClient
import com.desigurway.trgold.databinding.FragmentRegisterBinding
import com.desigurway.trgold.model.StatusMessageModel
import com.desigurway.trgold.utils.AndroidUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.lang.Exception


class RegisterFragment : Fragment() {

    lateinit var binding: FragmentRegisterBinding
    lateinit var mContext: Context
    lateinit var userNameEt: EditText
    lateinit var userEmailEt: EditText
    lateinit var userPhoneEt: EditText
    lateinit var userAddressEt: EditText
    lateinit var userPwdEt: EditText
    lateinit var userConfPwdEt: EditText
    lateinit var loginHereTv:TextView
    lateinit var registerUserDetailsBtn: Button
    lateinit var actions:NavDirections


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRegisterBinding.inflate(inflater, container, false)
        mContext = requireContext()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userNameEt = binding.nameEt
        userEmailEt = binding.emailEt
        userPhoneEt = binding.phoneEt
        userAddressEt = binding.addressEt
        userPwdEt = binding.createPasswordEt
        userConfPwdEt = binding.confirmPasswordEt
        registerUserDetailsBtn = binding.registerBtn
        loginHereTv=binding.loginTv

        loginHereTv.setOnClickListener {
            actions=RegisterFragmentDirections.actionRegisterFragmentToLoginFragment()
            Navigation.findNavController(view).navigate(actions)
        }

        registerUserDetailsBtn.setOnClickListener {
            checkData(view)

        }
    }

        private suspend fun userRegistration(
            name: String,
            email: String,
            phone: String,
            address: String,
            password: String,
            userType: String
        ): Response<StatusMessageModel> {
            return withContext(Dispatchers.IO) {
                BaseClient.getInstance.userRegistration(
                    name,
                    email,
                    phone,
                    address,
                    password,
                    userType
                )
            }
        }



        fun checkData(view: View){
            val name = userNameEt.text.toString().trim()
            val email = userEmailEt.text.toString().trim()
            val phoneNum = userPhoneEt.text.toString().trim()
            val address = userAddressEt.text.toString().trim()
            val pwd = userPwdEt.text.toString().trim()
            val confPwd = userConfPwdEt.text.toString().trim()
            val userType = "customer"


            if (!AndroidUtils().checkNetworkAvailability(mContext)) {
                Toast.makeText(
                    mContext,
                    "Please check your internet connection",
                    Toast.LENGTH_SHORT
                ).show()
                    return
            }


            if (name.isEmpty()) {
                userNameEt.error = "Required fields"
                userNameEt.requestFocus()
                return
            }

            if (email.isEmpty()) {
                userEmailEt.error = "Required fields"
                userEmailEt.requestFocus()
                return
            }

            if (phoneNum.isEmpty()) {
                userPhoneEt.error = "Required fields"
                userPhoneEt.requestFocus()
                return
            }

            if (address.isEmpty()) {
                userAddressEt.error = "Required fields"
                userAddressEt.requestFocus()
                return
            }

            if (pwd.isEmpty()) {
                userPwdEt.error = "Required fields"
                userPwdEt.requestFocus()
                return
            }

            if (confPwd.isEmpty()) {
                userConfPwdEt.error = "Required fields"
                userConfPwdEt.requestFocus()
                return
            }

            if (pwd != confPwd) {
                userPwdEt.error = "Passwords do not match"
                userConfPwdEt.error = "Passwords do not match"
                userConfPwdEt.requestFocus()
                userPwdEt.requestFocus()
                return
            }

            if (!AndroidUtils().validEmail(email)) {
                userEmailEt.error = "Enter valid Email Address"
                userEmailEt.requestFocus()
                return
            }


            CoroutineScope(Dispatchers.Main).launch {
                try {

                    val response = userRegistration(
                        name,
                        email,
                        phoneNum,
                        password = pwd,
                        address = address,
                        userType = userType
                    )
                    if (response.isSuccessful) {
                        val data = response.body()
                        if (data?.status.equals("1")) {

                            Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()
                            actions=RegisterFragmentDirections.actionRegisterFragmentToLoginFragment()
                            Navigation.findNavController(view).navigate(actions)
                        } else {
                            Toast.makeText(mContext, data?.message, Toast.LENGTH_SHORT).show()

                        }

                    } else {
                        Toast.makeText(mContext, response.message(), Toast.LENGTH_SHORT).show()

                    }
                } catch (e: Exception) {
                    Toast.makeText(mContext, e.localizedMessage, Toast.LENGTH_SHORT).show()

                }
            }
        }

               }

