package com.desigurway.trgold.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build

/**
 * Created by SR00136 on 20 Apr, 2021
 */
class AndroidUtils {

    fun checkNetworkAvailability(context: Context):Boolean{
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

            val capabilities = cm.getNetworkCapabilities(cm.activeNetwork)
            if(capabilities!=null){
                when{
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ->{
                        return true
                    }

                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->{
                        return true
                    }

                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->{
                        return true
                    }
                }
            }

        }else{

            val activeNetworkInfo = cm.activeNetworkInfo
            if(activeNetworkInfo!=null && activeNetworkInfo.isConnected){
                return true
            }
        }
        return false
    }

    fun validEmail(email:String):Boolean{
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}